public class HelloWorld {
    var m = 1;
//     hokdbfsd
// ihdgiew
// ewfpiweof
// aefo
    public static void main(String[] args) {
        System.out.println("Hello World");
        var i = 1;
        char kkk = 4;
        int k = 2;
    }
    public static void jjj(String[] args) {
        System.out.println("Hello World");
        var l = 1;
        int aaaa = 2;
    }
}